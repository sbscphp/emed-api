<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            PermissionTableSeeder::class,
            // RolePermissionSeeder::class,
            // UsersTableSeeder::class,
            // TenantUserSeeder::class,
            // ServicesTableSeeder::class,
            // StateSeeder::class,
            // ServiceUnitSeeder::class,
        ]);

        $this->call(MySqlDumpSeeder::class);
    }
}
